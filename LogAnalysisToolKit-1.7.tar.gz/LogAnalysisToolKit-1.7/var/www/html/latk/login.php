<?php
////////////////////////////
//Log Analysis Tool Kit (LATK)
//version 1.7 2012.04.19
//Copyright (C) 2011 Joe McManus - joe@cert.org
//This program is free software: you can redistribute it and/or modify
//it under the terms of the GNU General Public License as published by
//the Free Software Foundation, either version 3 of the License, or
//at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program.  If not, see <http://www.gnu.org/licenses/>.
////////////////////////////
?>
<html>
 <head>
 <title> LATK: Log Analysis Tool Kit Login </title> 
 </head>
 <body> 
 <link rel="stylesheet" type="text/css" href="latk.css">
 <img src=latk-banner.png>
<center>
<form method=post action=index.php>
 <fieldset>
	<legend>Log Analysis Tool Kit|Login</legend> 
	<p><label for "formuser"> Username </label> <input type="text" id="formuser" name="formuser"></p>
	<p><label for "pass"> Password </label> <input type="password" id="pass" name="pass"></p>
	<p class="submit"><input type="submit" value="submit" name=submit></p>
 </fieldset>
</form> 
</center>
</body>
</html>

